const firebaseConfig = {
    apiKey: "AIzaSyAGLd-DSSgQxiFIxmP5XwDFCyXfidu-Y3Q",
    authDomain: "moms-recipes-da228.firebaseapp.com",
    projectId: "moms-recipes-da228",
    storageBucket: "moms-recipes-da228.appspot.com",
    messagingSenderId: "863564307422",
    appId: "1:863564307422:web:c566dea42abbfbd2149b4f"
  };

  const app = initializeApp(firebaseConfig);
  var firebase=firebase.firbase()

  const db=firestore.collection("formData")